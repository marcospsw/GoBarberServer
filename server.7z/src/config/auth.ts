export default {
  jwt: {
    secret: 'cb075ef4c34795c4616126ae57e64696',
    expiresIn: '1d'
  }
};
