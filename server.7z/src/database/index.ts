import { createConnection } from 'typeorm';

createConnection();
